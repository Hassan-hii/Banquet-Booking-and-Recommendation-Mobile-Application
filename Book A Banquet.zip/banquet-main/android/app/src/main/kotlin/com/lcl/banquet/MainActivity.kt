package com.lcl.banquet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
